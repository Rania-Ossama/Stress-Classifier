import pandas as pd

df_go = pd.read_csv('goemotions_filtered.csv')
df_reddit = pd.read_csv('reddit_filtered.csv')
df_youtube = pd.read_csv('youtube_scraped_filtered.csv')


df_go.rename(columns={'stress_level': 'label'}, inplace=True)
df_reddit.rename(columns={'stress_level': 'label'}, inplace=True)

for df in [df_go, df_reddit, df_youtube]:
    df['label'] = df['label'].astype(str).str.strip().str.lower()

final_df = pd.concat([df_go, df_reddit, df_youtube], ignore_index=True)

final_df.to_csv('stress_dataset_final_merged.csv', index=False)

print("merge done!")
print("num of rows:", len(final_df))
print("\n labels:")
print(final_df['label'].value_counts())