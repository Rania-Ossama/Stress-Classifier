import csv
from pathlib import Path

# تحديد المسار الحالي للسكربت
BASE_DIR = Path(__file__).resolve().parent

def tsv_to_csv(name):
    input_path = BASE_DIR / name
    output_path = input_path.with_suffix(".csv") # تغيير الامتداد باحترافية

    # التأكد من أن الملف موجود فعلاً قبل البدء
    if not input_path.exists():
        print(f"⚠️ الملف {name} غير موجود في المسار، تم تخطيه.")
        return

    with open(input_path, "r", encoding="utf-8") as tsv_file:
        # قراءة الملف مع تحديد الـ Tab كمحدد
        reader = csv.reader(tsv_file, delimiter="\t")

        with open(output_path, "w", newline="", encoding="utf-8") as csv_file:
            writer = csv.writer(csv_file)
            writer.writerows(reader)
    
    print(f"✅ تم تحويل {name} بنجاح إلى {output_path.name}")

# تنفيذ التحويل لملفات الداتا سيت
for file_name in ["dev.tsv", "test.tsv", "train.tsv"]:
    tsv_to_csv(file_name)